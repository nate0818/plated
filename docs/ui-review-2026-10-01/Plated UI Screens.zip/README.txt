Plated UI screen review images

91 numbered images: app screens and states (A), widget and timer layouts (W), and share extension states (X). Open manifest.csv to map screen IDs to filenames. Images are review captures using sample data; widget and timer layouts are source previews.
